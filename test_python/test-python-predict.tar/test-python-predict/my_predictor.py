

class MyPredictor:
    def __init__(self):
        print("My predictor init")

    def predict(self, sample):
        print("Running predict: {}".format(sample))
        return 1